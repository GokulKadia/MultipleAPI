﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreApiAdoDemo.Model
{
    public class MySettingsModel
    {
        public string DbConn { get; set; }
    }
}
