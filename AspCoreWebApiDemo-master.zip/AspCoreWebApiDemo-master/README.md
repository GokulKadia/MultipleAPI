# ASP.NET Core Web Api Demo
ASP.NET Core Web API with ADO.NET.

This is the entire code for the CRUD operation in ASP.NET Core Web API using ADO.NET.
I've also added the script of database in wwwroot>Content>DbBackup.
Database used was Microsoft SQL Server and script includes the entire schema with data.
